import React from 'react';
import { StyleSheet, Text, View, Image, Button} from 'react-native';

export default function App(props) {
  return (
    <View style={styles.container}>
    <Image source={{uri:'https://hungarytoday.hu/wp-content/uploads/2019/05/black_widow.jpg'}}
        style={{ width: 300, height: 200}}/>
  <Text style={styles.text}>Black Widow</Text>
  {/* <Button title='Friends' type="outline"  color='green' onPress={()=> props.navigation.navigate('MyFriends')} /> */}
  <View style={styles.addSquare}>
<Button title='Friends' type="outline"  color='white' onPress={()=> props.navigation.navigate('MyFriends')} />
      </View>
  </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    alignItems: 'center',
    justifyContent: 'center',
    
  },
  text:{
  fontSize: 25,
  padding: 25,
  color: 'white',
  fontWeight: 'bold'
  },
  threebar: {
    position: 'absolute',
    left: 30,
    top: 30
  },
  addSquare:{
    height: 40,
    width: 80,
    backgroundColor: 'red',
  }

});