import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import MyProfile from './pages/MyProfile';
import FriendInfo from './pages/FriendInfo';
import MyFriends from './pages/MyFriends';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator stackContentOptions={
        {
          activeBackgroundColor: 'lime',
          activeTintColor: 'magenta',
          inactiveBackgroundColor: 'yellow',
          inactiveTintColor: '#ff0000',
          labelStyle: {
            fontSize: 16,
            fontWeight: 'bold'
          }
        }
      }>
        <Stack.Screen name='MyProfile' component={MyProfile} options={{title: 'My Profile', textColor: 'white'}} />
        <Stack.Screen name='FriendInfo' component={FriendInfo} options={{title: 'Friend Info', textColor: 'white'}} />
        <Stack.Screen name='MyFriends' component={MyFriends} options={{title: 'My Friends', textColor: 'white'}} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'blue',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
